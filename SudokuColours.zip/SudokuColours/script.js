let colours = [
    "#FD3B62",
    "#FC8849",
    "#ffed4a",
    "#38c172",
    "#4dc0b5",
    "#3490dc",
    "#577590",
    "#9561e2",
    "#f66d9b"
];
// Means that grid 'null' value corelates to white
colours[-1] = "#FFFFFF"

function Vector2(x, y) {
    this.x = x;
    this.y = y;
}

let gameOver = false;
let currentDifficulty = "2"; // 1: Hard - 3: Easy
let grid = [];
let leaderboardPlacards = document.getElementsByClassName("HighscoreContainer");

// Initialises website
function init() {
    generateGameContainer();
    generateSelectionPanel();

    // Reset timer to 0;
    displayTime(0);

    // Set starting colour to first in colour list
    selectedColour = colours[0];
    document.getElementById("SelectionPanel").children[0].classList.add("Selected");

    // Generate Game
    newGame();

    // Set Leaderboard
    updateLeaderboardScores();
    updateLeaderboardNames();
}

// Generates the game board (9x9)
function generateGameContainer() {
    // Reference to 'gameContainer' parent element
    let gameContainer = document.getElementById("GameContainer");
    // First 'for loop' is to generate 9 squares
    for (let i = 0; i < 9; i++) {
        let gameSquare = document.createElement("div");
        gameSquare.classList.add("GameSquare");
        gameContainer.appendChild(gameSquare);
        grid[i] = [];
        //Second 'for loop' is to generate 9 tiles
        for (let j = 0; j < 9; j++) {
            let gameTile = document.createElement("div");
            gameTile.classList.add("GameTile");
            gameTile.addEventListener("click", updateTile);
            gameSquare.appendChild(gameTile);
            // Set grid tile value to 'null' value
            grid[i][j] = -1;
        }
    }
}
// Generates the colour selection panel (3x3)
function generateSelectionPanel() {
    // Reference to parent selection panel element
    let selectionPanel = document.getElementById("SelectionPanel");
    for (let i = 0; i < 9; i++) {
        let button = document.createElement("div");
        button.classList.add("SelectionButton");
        button.style.backgroundColor = colours[i];
        button.id = colours[i];
        button.addEventListener("click", selectColour);
        selectionPanel.appendChild(button);
    }
}

// Timer
let elapsedTime = 0;
function incrementTime() {
    if (!gameOver)
        elapsedTime += 1;
    // Update timer display
    document.getElementById("Timer").innerHTML = displayTime(elapsedTime);
}
function displayTime(time) {
    let mins = Math.floor(time / 60);
    let secs = time % 60;
    secs = (secs < 10) ? "0" + secs.toString() : secs.toString();
    display = mins.toString() + ":" + secs;
    return display;
}
// Calls 'increment time' every second (1000 milisecs)
document.getElementById("Timer").innerHTML = displayTime(elapsedTime);
window.setInterval(incrementTime, 1000); 

// Initialise 'New Game'
function newGame() {
    // Reset GameOverPopUp
    document.getElementById("GameOverPopup").style.visibility = "hidden";
    document.getElementById("GameOverPopup").style.opacity = 0;

    //Reset Gamestate
    gameOver = false;
    
    // Reset timer & Update display
    elapsedTime = 0;
    document.getElementById("Timer").innerHTML = displayTime(0);

    // Generate solved puzzle
    let validPuzzle = false;
    while (validPuzzle == false) {
        validPuzzle = true;
        grid = generatePuzzle();
        for (let i = 0; i < 9; i++) {
            for (let j = 0; j < 9; j++) {
                if (grid[i][j] == undefined) {
                    validPuzzle = false;
                }
            }
        }
    }
    let revealedTiles = 50;
    switch (currentDifficulty) {
        case 1: // Hard
            revealedTiles = 30;
            break;
        case 2: // Medium
            revealedTiles = 50;
            break;
        case 3: // Easy
            revealedTiles = 70;
            break;
    }
    // Remove tiles
    for (let i = 0; i < 81 - (revealedTiles); i++) {
        grid[Math.floor(Math.random() * 9)][Math.floor(Math.random() * 9)] = -1;
    }

    // Reset game board
    gameContainer = document.getElementById("GameContainer");
    for (let i = 0; i < 9; i++) {
        let gameSquare = gameContainer.children[i];
        for (let j = 0; j < 9; j++) {
            let gameTile = gameSquare.children[j];
            // Set background of tiles to white and reset grid to null value
            gameTile.style.backgroundColor = colours[grid[i][j]];
        }
    }

    // Reset leaderboards
    for (let i = 0; i < leaderboardPlacards.length; i++) {
        leaderboardPlacards[i].getElementsByTagName("input")[0].readOnly = "readOnly";
    }
}

// Generate Sudoku puzzle (Wave Function Collapse Algorithm)
function generatePuzzle() {
    // Generate blank puzzle (mimics 'grid')
    let puzzle = [];
    let puzzleSuperpositions = [];
    for (let i = 0; i < 9; i++) {
        puzzle[i] = [];
        puzzleSuperpositions[i] = []
        for (let j = 0; j < 9; j++) {
            // Set puzzle tile value to 'null' value
            puzzle[i][j] = -1;
            puzzleSuperpositions[i][j] = [];
            for (let k = 0; k < 9; k++) {
                // Each tile in 'puzzlePotentials' holds a number for all its potential values (initially 0 - 8)
                puzzleSuperpositions[i][j].push(k);
            }
        }
    }

    for (let i = 0; i < 81; i++) {
        // Create array of minEntropyCells with their index's
        let minEntropyCells = [];
        let entropy = 9; 
        for (let i = 0; i < 9; i++) {
            for (let j = 0; j < 9; j++) {
                let cell = puzzleSuperpositions[i][j];
                if (cell.length < entropy) {
                    entropy = cell.length;
                    minEntropyCells = [0];
                    minEntropyCells = [[cell, [i, j]]];
                }
                if (cell.length == entropy) {
                    minEntropyCells.push([cell, [i, j]]);
                }
            }
        }
        // Choose random cell from minEntropyCells
        let chosenCell = minEntropyCells[Math.floor(Math.random() * minEntropyCells.length)];
        let chosenCellIndex = chosenCell[1];
        chosenCell = chosenCell[0];
        // Choose random value from remianing values
        let chosenCellValue = chosenCell[Math.floor(Math.random() * chosenCell.length)];
        // update puzzle and puzzle superpositions with new value
        puzzle[chosenCellIndex[0]][chosenCellIndex[1]] = chosenCellValue;
        puzzleSuperpositions[chosenCellIndex[0]][chosenCellIndex[1]] = new Array(10); // Empty Array larger than default so not caught in entropy tester
        for (let i = 0; i < 9; i++) {
            for (let j = 0; j < 9; j++) {
                if (!checkActionIsLegal(puzzle, [i, j], chosenCellValue)) { // still need to ensure that this doesn't interact witht the item just placed 
                    // ensure when removing value that arrays of 10 (filled in cells) are accounted for
                    let index = puzzleSuperpositions[i][j].indexOf(chosenCellValue);
                    if (index > -1) {
                        puzzleSuperpositions[i][j].splice(index, 1);
                    }              
                }
            }
        }
        // Repeat as required
    }

    return puzzle;
}

// Colour Selection
let selectedColour = null;
function selectColour(event) {
    let button = event.target;
    let panel = document.getElementById("SelectionPanel");
    // Remove 'selected' attribute from colour buttons
    for (let i = 0; i < 9; i++) {
        panel.children[i].classList.remove("Selected");
    }
    // Apply 'selected' attribute to selected colout button
    button.classList.add("Selected");
    // id is used to communicate selected colour over background(rgb) to maintain hex
    selectedColour = button.id;
}

function updateTile(event) {
    let tile = event.target;

    // Get tile and colour index's to make comparisons easier
    // Finds tileIndex
    let index = getGridIndexOfTile(tile);
    // Find ColourIndex in colour array
    selectedColourIndex = -1;
    for (let i = 0; i < 9; i++) {
        if (selectedColour == colours[i]) {
            selectedColourIndex = i;
        }
    }
    // Check if move is legal by sudoku rules
    if (!checkActionIsLegal(grid, index, selectedColourIndex))
        return;

    // Updates tile display and in grid
    tile.style.backgroundColor = selectedColour;
    grid[index[0]][index[1]] = selectedColourIndex;

    boardIsFilled = true;
    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            if (grid[i][j] == -1) {
                boardIsFilled = false;
            }
        }
    }
    gameOver = boardIsFilled;
    if (gameOver)
        onGameOver()
}

function onGameOver() {
    document.getElementById("GameOverPopup").style.visibility = "visible";
    document.getElementById("GameOverPopup").style.opacity = 1;

    updateLeaderboardScores(elapsedTime);
    updateLeaderboardNames();
}

function checkActionIsLegal(puzzle, tileIndex, colourIndex) {
    let isLegal = true;
    for (let i = 0; i < 9; i++) {
        if (puzzle[tileIndex[0]][i] == colourIndex) {
            isLegal = false;
            //console.log("Illegal Move: more than one occurance of colour in square.")
        }
    }

    let gridCol = tileIndex[0] % 3;
    let squareCol = tileIndex[1] % 3;
    let gridRow = Math.floor(tileIndex[0]/3);
    let squareRow = Math.floor(tileIndex[1]/3);

    // Checks column for duplicates
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (puzzle[gridCol + 3 * i][squareCol + 3 * j] == colourIndex) {
                isLegal = false;
                //console.log("Illegal Move: more than one occurance of colour in column.")
            }
        }
    }
    // Checks row for duplicates
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (puzzle[gridRow * 3 + i][squareRow * 3 + j] == colourIndex) {
                isLegal = false;
                //console.log("Illegal Move: more than one occurance of colour in row.")
            }
        }
    }

    return isLegal;
}

function getGridIndexOfTile(tile) {
    let square = tile.parentElement;
    let game = square.parentElement;
    // Null index value
    let index = [-1,-1];
    // Finds the index of the tile in the square
    for (let i = 0; i < 9; i++) {
        if (tile == square.children[i]) {
            index[1] = i
        }
    }
    // Finds the index of the tile's parent (square) in the grid
    for (let j = 0; j < 9; j++) {
        if (square == game.children[j]) {
            index[0] = j;
        }
    }
    return index;
}

function updateDifficulty(difficulty) {
    let parent = difficulty.parentElement;
    for (let i = 0; i < 4; i++) {
        if (parent.children[i] == difficulty) {
            currentDifficulty = i;
            parent.children[i].classList.add("SelectedDifficulty");
        } else {
            parent.children[i].classList.remove("SelectedDifficulty");
        }
    }
    newGame();
    updateLeaderboardScores();
    updateLeaderboardNames();
}

// Initialise localstorage
let leaderboardId = "highscores";
localStorage.removeItem("Highscores");
if (localStorage.getItem(leaderboardId) == null) {
    localStorage.setItem(leaderboardId, JSON.stringify(new Array(JSON.stringify(new Array()), 
                                                                JSON.stringify(new Array()), 
                                                                JSON.stringify(new Array()))));
}
function updateLeaderboardScores(newTime) {
    currentHighscoreIndex = null;
    let highscores = JSON.parse(localStorage.getItem(leaderboardId));
    let currentHighscores = JSON.parse(highscores[currentDifficulty - 1]);

    if (currentHighscores.length == 0) {
        currentHighscores = new Array();
        for (let i = 0; i < leaderboardPlacards.length; i++) {
            currentHighscores.unshift(new Vector2("", 0));
        }
    }
    
    for (let i = 0; i < currentHighscores.length; i++) {
        if ((currentHighscores[i].y == 0 || newTime < currentHighscores[i].y) && newTime !== undefined) {
            currentHighscores.splice(i, 0, new Vector2("", newTime));
            currentHighscores.pop();
            leaderboardPlacards[i].getElementsByTagName("input")[0].readOnly = false;
            leaderboardPlacards[i].getElementsByTagName("input")[0].focus();
            currentHighscoreIndex = i;
            i = currentHighscores.length;
        }
    }
    
    for (let i = 0; i < leaderboardPlacards.length; i++) {
        leaderboardPlacards[i].childNodes[1].innerHTML = displayTime(currentHighscores[i].y);
    }
    
    highscores[currentDifficulty - 1] = JSON.stringify(currentHighscores);
    localStorage.setItem(leaderboardId, JSON.stringify(highscores));
}

// Writes related name to time on leaderboard
function updateLeaderboardNames(name) {
    let highscores = JSON.parse(localStorage.getItem(leaderboardId));
    let currentHighscores = JSON.parse(highscores[currentDifficulty - 1]);

    if (currentHighscoreIndex != null && name != undefined) {
        currentHighscores[currentHighscoreIndex].x = name;
    }

    for (let i = 0; i < currentHighscores.length; i++) {
        leaderboardPlacards[i].getElementsByTagName("input")[0].value = currentHighscores[i].x;
    }

    highscores[currentDifficulty - 1] = JSON.stringify(currentHighscores);
    localStorage.setItem(leaderboardId, JSON.stringify(highscores));
}

$(function() {
    $('.LeaderboardName').on('input', function() {
        updateLeaderboardNames($(this).val());
    });
});

// Inital function calls
init();